#!/bin/bash

/opt/anaconda2/bin/supervisorctl start all
